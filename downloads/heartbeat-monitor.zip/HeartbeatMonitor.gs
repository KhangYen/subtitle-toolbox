/**
 * Heartbeat Monitor — a dead-man's-switch for your cron jobs / scheduled
 * tasks, running entirely in your own Google account.
 *
 * The problem this solves: a scheduled job can fail to even START (not
 * crash — just silently never run) and nothing tells you. You find out
 * days later when someone notices the thing it was supposed to do never
 * happened. Services like Healthchecks.io / Cronitor solve this for
 * $10-50+/month. This is the same idea, self-hosted, one-time.
 *
 * SETUP (5 minutes):
 * 1. Make a copy of the Heartbeat Monitor Google Sheet.
 * 2. Extensions > Apps Script, paste this whole file in, save.
 * 3. Deploy > New deployment > type "Web app" > Execute as "Me" >
 *    Who has access: "Anyone" > Deploy. Copy the Web App URL it gives
 *    you — that URL is your secret. Anyone who has it can check in as
 *    any job name, so don't post it publicly (same security model as
 *    every cron-monitoring service's ping URLs).
 * 4. In the Apps Script editor's function dropdown, select
 *    "setupTrigger", click Run, authorize when asked.
 * 5. At the end of each job/script/cron task you want watched, add one
 *    step that hits your URL with a job name, e.g.:
 *      curl "<your-web-app-url>?job=nightly-backup"
 *    First hit auto-creates the row (default: expects a check-in every
 *    24h). Edit that row's "Expected Interval (hours)" afterward to
 *    match your job's real schedule.
 * 6. If a job goes silent past its interval (x1.5 grace), you get one
 *    email. When it checks in again, you get one "recovered" email.
 *    Never spams — one notification per state change, not per check.
 */

const SHEET_NAME = "Jobs";
const DEFAULT_INTERVAL_HOURS = 24;
const DEFAULT_GRACE_MULTIPLIER = 1.5;

const COLUMNS = [
  "Job Name", "Expected Interval (hours)", "Grace Multiplier",
  "Last Check-in", "Status", "Alert Email (optional)",
];

function setupTrigger() {
  ScriptApp.getProjectTriggers().forEach(function (t) {
    if (t.getHandlerFunction() === "checkOverdue") ScriptApp.deleteTrigger(t);
  });
  ScriptApp.newTrigger("checkOverdue").timeBased().everyHours(1).create();
  SpreadsheetApp.getUi().alert(
    "Set up! Heartbeat Monitor checks every hour for overdue jobs. " +
    "Point your cron jobs at your Web App URL (Deploy > Manage " +
    "deployments to see it again) with ?job=yourjobname."
  );
}

// Pure decision logic — zero dependency on Sheets/Gmail/HTTP, so it was
// (and can be re-) unit-tested outside Apps Script before shipping.
function isOverdue(lastCheckinMs, expectedIntervalHours, nowMs, graceMultiplier) {
  const grace = graceMultiplier || DEFAULT_GRACE_MULTIPLIER;
  const graceMs = expectedIntervalHours * 3600 * 1000 * grace;
  return (nowMs - lastCheckinMs) > graceMs;
}

function nextStatus(currentlyOverdue, previousStatus) {
  if (currentlyOverdue && previousStatus !== "OVERDUE") return { status: "OVERDUE", notify: "alert" };
  if (!currentlyOverdue && previousStatus === "OVERDUE") return { status: "OK", notify: "recovered" };
  return { status: currentlyOverdue ? "OVERDUE" : "OK", notify: null };
}

// doGet handles check-ins: GET <web-app-url>?job=<name>
function doGet(e) {
  const jobName = (e.parameter.job || "").trim();
  if (!jobName) return ContentService.createTextOutput("Missing ?job=name parameter");

  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
  const data = sheet.getDataRange().getValues();
  const headers = data[0];
  const col = function (name) { return headers.indexOf(name); };

  let rowIndex = -1;
  for (let i = 1; i < data.length; i++) {
    if (data[i][col("Job Name")] === jobName) { rowIndex = i; break; }
  }

  const now = new Date();
  if (rowIndex === -1) {
    // New job seen for the first time — auto-create with sane defaults.
    sheet.appendRow([jobName, DEFAULT_INTERVAL_HOURS, DEFAULT_GRACE_MULTIPLIER, now, "OK", ""]);
  } else {
    sheet.getRange(rowIndex + 1, col("Last Check-in") + 1).setValue(now);
    sheet.getRange(rowIndex + 1, col("Status") + 1).setValue("OK");
  }
  return ContentService.createTextOutput("OK " + jobName + " " + now.toISOString());
}

function checkOverdue() {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
  const data = sheet.getDataRange().getValues();
  const headers = data[0];
  const col = function (name) { return headers.indexOf(name); };
  const now = new Date();
  const ownerEmail = Session.getEffectiveUser().getEmail();

  for (let i = 1; i < data.length; i++) {
    const row = data[i];
    const jobName = row[col("Job Name")];
    if (!jobName) continue;
    const lastCheckin = row[col("Last Check-in")];
    if (!lastCheckin) continue;
    const intervalHours = Number(row[col("Expected Interval (hours)")]) || DEFAULT_INTERVAL_HOURS;
    const grace = Number(row[col("Grace Multiplier")]) || DEFAULT_GRACE_MULTIPLIER;
    const previousStatus = row[col("Status")];

    const overdue = isOverdue(new Date(lastCheckin).getTime(), intervalHours, now.getTime(), grace);
    const decision = nextStatus(overdue, previousStatus);

    if (decision.notify) {
      const to = row[col("Alert Email (optional)")] || ownerEmail;
      const hoursSince = Math.round((now.getTime() - new Date(lastCheckin).getTime()) / 3600000);
      if (decision.notify === "alert") {
        GmailApp.sendEmail(to,
          "⚠ Heartbeat missed: " + jobName,
          "\"" + jobName + "\" was expected to check in every " + intervalHours +
          "h, but hasn't been heard from in " + hoursSince + "h.\n\n" +
          "Last check-in: " + lastCheckin + "\n\n" +
          "If this job is supposed to have stopped, mark it inactive by " +
          "clearing its row, or increase its interval.");
      } else {
        GmailApp.sendEmail(to,
          "✅ Recovered: " + jobName,
          "\"" + jobName + "\" checked in again after being overdue. All good.");
      }
    }
    sheet.getRange(i + 1, col("Status") + 1).setValue(decision.status);
  }
}
