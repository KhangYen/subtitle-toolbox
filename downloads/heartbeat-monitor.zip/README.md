# Heartbeat Monitor — $15

A dead-man's-switch for your cron jobs and scheduled tasks, running
entirely in your own Google account. If a job goes silent, you get one
email. When it comes back, you get one more. Never spams.

**Why this exists:** a scheduled job's most dangerous failure mode
isn't crashing loudly — it's silently never launching at all, with
nothing telling you. Services like Healthchecks.io and Cronitor solve
this for $10-50+/month. This is the same idea, self-hosted, one-time.

## Setup (5 minutes)

1. Open Google Sheets, create a blank spreadsheet, rename the first tab
   to **Jobs**.
2. File → Import → Upload → `Jobs-template.csv` → Import location:
   **Replace current sheet**.
3. Extensions → Apps Script. Delete the placeholder, paste in the
   entire contents of `HeartbeatMonitor.gs`. Save.
4. Deploy → New deployment → type **Web app** → Execute as **Me** →
   Who has access: **Anyone** → Deploy. **Copy the Web App URL** — this
   is your secret; anyone with it can check in as any job name, so
   don't post it publicly. (Same security model every cron-monitoring
   service uses for its ping URLs.)
5. In the function dropdown, select **setupTrigger**, click **Run**,
   authorize when asked.
6. Add one line to the end of any job you want watched:
   ```
   curl "<your-web-app-url>?job=nightly-backup"
   ```
   First check-in auto-creates the row with a default 24h interval —
   edit that row afterward to match your job's real schedule.

## The columns

| Column | What it means |
|---|---|
| Job Name | Whatever you pass as `?job=` |
| Expected Interval (hours) | How often this job should check in |
| Grace Multiplier | How much slack before it's "overdue" (default 1.5×) |
| Last Check-in / Status | Written automatically — don't edit by hand |
| Alert Email (optional) | Leave blank to use your own account's email |

## Notes

- Checks run every hour; one email per state change (missed → alert,
  recovered → one more), never repeated for an unchanged state.
- To stop watching a job, delete its row.
- Everything is plain, commented code in `HeartbeatMonitor.gs` — change
  the default interval, grace multiplier, or email wording freely.

## Tested before shipping

The overdue/notification decision logic was extracted as pure functions
(`isOverdue`, `nextStatus`) and unit-tested (11/11 cases —
`test_overdue_logic.js`) before being wired into the real script, since
Apps Script's Sheets/Gmail/HTTP APIs only run inside its own runtime
and can't be tested directly outside it.

## Gumroad listing

**Title:** Heartbeat Monitor — a self-hosted dead-man's-switch for your
cron jobs ($15, no subscription)

**Description:**
> Ever had a scheduled job silently stop running, with nothing telling
> you until it was too late? This watches your cron jobs / scheduled
> tasks and emails you the moment one goes silent — and once more when
> it recovers. Runs entirely in your own Google account.
>
> - One curl call at the end of any job to check in
> - Auto-detects new jobs, no manual config to add one
> - One email per state change — never spams
> - $15 once vs. $10-50+/month for Healthchecks.io, Cronitor, etc.

**Tags:** DevOps, Monitoring, Cron, Automation, Self-hosted.

## Honest EV note

No demand-scan evidence for this one — sourced from our own direct,
just-experienced pain (a scheduled task failing silently with zero
visibility) plus an already-proven paid category. Different provenance
than Invoice Chaser (repeated external signal) — this is closer to
"dogfooding a real problem we hit," which is its own valid signal, just
a different kind. Re-evaluate honestly once there's any sales data.
