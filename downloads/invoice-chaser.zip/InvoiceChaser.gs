/**
 * Invoice Chaser — automated, escalating payment-reminder emails.
 *
 * SETUP (2 minutes):
 * 1. Make a copy of the "Invoice Chaser" Google Sheet (the one this came with).
 * 2. In your copy: Extensions > Apps Script.
 * 3. Delete any placeholder code, paste this whole file in, save.
 * 4. In the function dropdown (top toolbar), select "setupTrigger", click Run.
 * 5. Google will ask you to authorize — this script only ever reads/writes
 *    the "Invoices" sheet in THIS spreadsheet and sends email as you via
 *    your own Gmail. It never touches anything else, and never leaves
 *    your Google account.
 * That's it. It checks every morning and sends reminders automatically.
 *
 * HOW IT WORKS
 * Each row in the "Invoices" sheet is one invoice. Every day, this script
 * checks how many days overdue each unpaid invoice is, and — the first
 * time it crosses 3, 7, 14, or 30 days overdue — sends an email to that
 * client with an increasingly firm tone. It never re-sends the same
 * milestone twice, and never emails anything marked "Paid" or "Stopped".
 */

const SHEET_NAME = "Invoices";
const REMINDER_SCHEDULE_DAYS = [3, 7, 14, 30];

const COLUMNS = [
  "Client Name", "Client Email", "Invoice #", "Amount",
  "Due Date", "Status", "Last Reminder (days overdue)", "Last Reminder Sent On",
];

function setupTrigger() {
  ScriptApp.getProjectTriggers().forEach(function (t) {
    if (t.getHandlerFunction() === "checkAndSendReminders") {
      ScriptApp.deleteTrigger(t);
    }
  });
  ScriptApp.newTrigger("checkAndSendReminders")
    .timeBased()
    .everyDays(1)
    .atHour(9)
    .create();
  SpreadsheetApp.getUi().alert(
    "Set up! Invoice Chaser will check every morning around 9am and " +
    "send reminders automatically. Add your invoices to the Invoices " +
    "tab whenever you're ready."
  );
}

// Pure decision logic — deliberately has zero dependency on Sheets/Gmail
// so it can be (and was) unit-tested outside Apps Script before shipping.
function nextMilestoneFor(daysOverdue, lastSentDays) {
  const applicable = REMINDER_SCHEDULE_DAYS.filter(function (d) { return d <= daysOverdue; });
  const milestone = applicable.length ? applicable[applicable.length - 1] : null;
  if (!milestone || milestone === lastSentDays) return null;
  return milestone;
}

function checkAndSendReminders() {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
  if (!sheet) return;
  const data = sheet.getDataRange().getValues();
  const headers = data[0];
  const col = function (name) { return headers.indexOf(name); };

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  for (let i = 1; i < data.length; i++) {
    const row = data[i];
    const status = row[col("Status")];
    if (status === "Paid" || status === "Stopped") continue;
    if (!row[col("Client Email")] || !row[col("Due Date")]) continue;

    const dueDate = new Date(row[col("Due Date")]);
    dueDate.setHours(0, 0, 0, 0);
    const daysOverdue = Math.floor((today - dueDate) / 86400000);
    if (daysOverdue < REMINDER_SCHEDULE_DAYS[0]) continue;

    const lastSentDays = row[col("Last Reminder (days overdue)")] || null;
    const milestone = nextMilestoneFor(daysOverdue, lastSentDays);
    if (!milestone) continue;

    const clientName = row[col("Client Name")];
    const clientEmail = row[col("Client Email")];
    const invoiceNum = row[col("Invoice #")];
    const amount = row[col("Amount")];

    const msg = buildReminder(milestone, clientName, invoiceNum, amount, dueDate);
    GmailApp.sendEmail(clientEmail, msg.subject, msg.body);

    // Only ever touches the two tracking columns — your own "Status"
    // (Unpaid/Paid/Stopped) is yours to set and is never overwritten.
    sheet.getRange(i + 1, col("Last Reminder (days overdue)") + 1).setValue(milestone);
    sheet.getRange(i + 1, col("Last Reminder Sent On") + 1).setValue(today);
  }
}

function buildReminder(daysOverdue, clientName, invoiceNum, amount, dueDate) {
  const dueStr = Utilities.formatDate(dueDate, Session.getScriptTimeZone(), "MMM d, yyyy");
  if (daysOverdue <= 3) {
    return {
      subject: "Quick reminder: Invoice " + invoiceNum + " (" + amount + ")",
      body: "Hi " + clientName + ",\n\nJust a friendly reminder that invoice " +
        invoiceNum + " for " + amount + ", due " + dueStr +
        ", hasn't come through yet. Could you let me know the status when " +
        "you get a chance?\n\nThanks!",
    };
  } else if (daysOverdue <= 14) {
    return {
      subject: "Following up: Invoice " + invoiceNum + " is now " + daysOverdue + " days overdue",
      body: "Hi " + clientName + ",\n\nFollowing up again on invoice " +
        invoiceNum + " for " + amount + " (due " + dueStr + "). It's now " +
        daysOverdue + " days past due. Please let me know if there's an " +
        "issue on your end, or when I can expect payment.\n\nThanks for " +
        "your attention to this.",
    };
  }
  return {
    subject: "Overdue notice: Invoice " + invoiceNum + " — " + daysOverdue + " days past due",
    body: "Hi " + clientName + ",\n\nInvoice " + invoiceNum + " for " + amount +
      " (due " + dueStr + ") is now " + daysOverdue + " days overdue. Please " +
      "arrange payment as soon as possible, or reply if you'd like to " +
      "discuss a payment plan.\n\nI'd appreciate a response by end of week.",
  };
}
