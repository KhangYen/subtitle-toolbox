# Invoice Chaser

Stop manually chasing clients for money. This is a Google Sheets template
that automatically emails clients escalating, polite-but-firm payment
reminders — at 3, 7, 14, and 30 days overdue — with zero ongoing work
from you.

No subscription, no third-party service, no account beyond your own
Google account. It runs entirely inside a Google Sheet you own, using
your own Gmail to send.

## Setup (2 minutes)

1. Open Google Sheets, create a blank spreadsheet, rename the first tab
   to **Invoices**.
2. File → Import → Upload → select `Invoices-template.csv` → Import
   location: **Replace current sheet**. This gives you the right columns
   and a couple of example rows to see the format (delete them once you
   understand it).
3. Extensions → Apps Script. Delete the placeholder `myFunction() {}`
   and paste in the entire contents of `InvoiceChaser.gs`. Save (the
   disk icon or Ctrl+S).
4. In the function dropdown at the top of the Apps Script editor,
   select **setupTrigger**, then click **Run**.
5. Google will ask you to authorize access — this is expected. The
   script only ever reads/writes the Invoices tab in this one
   spreadsheet, and sends email as you via your own Gmail. It cannot
   see or touch anything else in your Google account.
6. That's it. Add real invoices as rows. Every morning around 9am, the
   script checks for anything overdue and sends the right reminder
   automatically.

## The columns

| Column | What to put there |
|---|---|
| Client Name | Whatever you want the greeting to use |
| Client Email | Where the reminder goes |
| Invoice # | Your own reference number |
| Amount | Free text, e.g. `$450` — shown as-is in the email |
| Due Date | The date it was due (YYYY-MM-DD or your locale's date format) |
| Status | Leave blank or `Unpaid` while waiting; set to `Paid` or `Stopped` to silence reminders for that row — **this column is yours, the script never changes it** |
| Last Reminder (days overdue) / Last Reminder Sent On | Written automatically by the script — don't edit these by hand |

## Notes

- Reminders are sent once per milestone (3/7/14/30 days) — never spammed,
  never repeated for the same milestone.
- Setting Status to `Paid` or `Stopped` immediately silences reminders
  for that row on the next daily check.
- Want different wording, different day thresholds, or a different
  send time? Everything is in `InvoiceChaser.gs` in plain, commented
  code — change `REMINDER_SCHEDULE_DAYS` or the `buildReminder` text
  and re-save.
